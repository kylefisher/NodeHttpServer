function AjaxRepository(serviceAddress) {
    var self = this;

    self.url = serviceAddress;

    self.makeServiceCall = function(method, callData, callback) {
       // var serviceUrl = "http://ks-kfisher-d01:8000/Cai/Apex/Services/Ticket/VehiclesInPlant/";
        $.ajax({
            type: 'POST',
            url: self.url + method,
            data: callData,
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            processData: false,
            success: function(msg) {
                callback(msg);
            },
            error: self.serviceCallFailed
        });
    };

    self.serviceCallFailed = function(result) {
        alert('Service call failed: ' + result.status + ', ' + result.statusText);
    };

    self.stationListReturned = function(result) {
        for (i = 0; i < result.GetStationsResult.length; i++) {
            var station = result.GetStationsResult[i];
            vehicleViewModel.stations.push(new Station(station.ID, station.Description));
        }
    };

    self.vehiclesReturned = function(result) {
        for (i = 0; i < result.GetVehiclesToLoadResult.length; i++) {
            var vehicle = result.GetVehiclesToLoadResult[i];

            var lastDateTimeIn = self.parseWcfJsonDate(vehicle.LastDateTimeIn);
            // do vehicle mapping and conversion here
            var timeIn = (Date.now() - lastDateTimeIn.getTime()) / (60 * 1000);

            //vehicleViewModel.vehicles.push(new Vehicle(vehicle.VehicleID, vehicle.VehicleDescription, timeIn));
            vehicleViewModel.addVehicle(new Vehicle(vehicle, timeIn));
        }
    };

    self.parseWcfJsonDate = function(jsonDateString) {
        var indexOfOpenParen = jsonDateString.indexOf('(');
        var indexOfCloseParen = jsonDateString.indexOf(')');
        var datePortion = jsonDateString.substring(indexOfOpenParen + 1, indexOfCloseParen);

        return new Date(parseInt(datePortion));
    };

    self.getStationList = function() {
        self.makeServiceCall('GetStations', '', self.stationListReturned);
    };

    self.getVehiclesToLoad = function(loadStation) {
        //var callData = '{ "locationID": "1", "loadStationID": "' + vehicleViewModel.selectedStation() + '" }';
        var callData = '{ "locationID": "1", "loadStationID": "'+ loadStation + '" }';
        self.makeServiceCall('GetVehiclesToLoad', callData, self.vehiclesReturned)
    };

    self.setVehicleLoaded = function(vehicleId, carrierId, isSplitLoad) {
        var splitLoad = 'N';

        if (isSplitLoad) {
            splitLoad = 'Y';
        }

        var callData = '{ "carrierID": "' + carrierId + '", "vehicleID": "' + vehicleId + '", "locationID": "1", "loadStationID": "' + vehicleViewModel.selectedStation() + '", "isSplitLoad": "' + splitLoad + '" }';
        self.makeServiceCall('SetVehicleToLoadStatus', callData);
    };

    self.setVehicleCheckOut = function(vehicleId, carrierId) {
        var callData = '{ "carrierID": "' + carrierId + '", "vehicleID": "' + vehicleId + '" }';
        self.makeServiceCall('SetVehicleToInOutStatus', callData);
    };
}
