//var repository = new AjaxRepository('http://ks-kfisher-d01:8000/Cai/Apex/Services/Ticket/VehiclesInPlant/');
//var repository = new AjaxRepository('http://ks-kfisher-vm6:8000/Cai/Apex/Services/Ticket/VehiclesInPlant/');
var repository = new AjaxRepository('http://192.168.0.107:8000/Cai/Apex/Services/Ticket/VehiclesInPlant/');

var vehicleViewModel = new VehiclesViewModel(repository);

window.setInterval(vehicleViewModel.updateModel, 60000);

window.addEventListener("load",function() {
    // Set a timeout...
    setTimeout(function(){
        // Hide the address bar!
        window.scrollTo(0, 1);
    }, 0);
});

$(document).ready(function() {

    repository.getStationList();
    repository.getVehiclesToLoad('');

    ko.applyBindings(vehicleViewModel);
});