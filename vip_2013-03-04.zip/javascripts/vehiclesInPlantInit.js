
/* Sample using jQuery's getScript to load javascript instead of using html
$.ajaxSetup({ async: false});
$.getScript('vehiclesInPlantConfig.js');
$.getScript('/models/Station.js');
$.getScript('/models/Vehicle.js');
$.getScript('/viewmodels/vehiclesInPlantViewModel.js');
$.getScript('AjaxRepository.js');
$.ajaxSetup({ async: true});
*/

var repository = new AjaxRepository(vehiclesInPlantConfig.serviceAddress);
var vehicleViewModel = new VehiclesViewModel(repository);

//window.setInterval(vehicleViewModel.updateModel, vehiclesInPlantConfig.refreshInterval);

window.addEventListener("load",function() {
    // Set a timeout...
    setTimeout(function(){
        // Hide the address bar!
        window.scrollTo(0, 1);
    }, 0);
});

$(document).ready(function() {

    repository.getStationList();
    repository.getVehiclesToLoad('');

    ko.applyBindings(vehicleViewModel);

    setInterval(vehicleViewModel.updateModel, vehiclesInPlantConfig.refreshInterval);
});