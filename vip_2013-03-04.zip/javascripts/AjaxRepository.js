function AjaxRepository(serviceAddress) {
    var self = this;
    self.url = serviceAddress;
    self.errorCount = 0;

    self.makeServiceCall = function(method, callData, callback) {
        $.ajax({
            type: 'POST',
            url: self.url + method,
            data: callData,
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            processData: false,
            success: function(msg) {
                callback(msg);
            },
            error: self.serviceCallFailed
        });
    };

    self.clearError = function() {
        self.errorCount = 0;
        vehicleViewModel.hideError();
    }

    self.serviceCallFailed = function(jqXHR, textStatus, errorThrown) {
        self.errorCount++;

        if (self.errorCount > 2) {
            vehicleViewModel.showError('Service communication has been lost.');
        }
    };

    self.stationListReturned = function(result) {
        vehicleViewModel.stations.removeAll();

        for (i = 0; i < result.GetStationsResult.length; i++) {
            var station = result.GetStationsResult[i];
            vehicleViewModel.stations.push(new Station(station.ID, station.Description));
        }

        self.clearError();
    };

    self.vehiclesReturned = function(result) {
        for (var i = 0; i < result.GetVehiclesToLoadResult.length; i++) {
            var vehicle = result.GetVehiclesToLoadResult[i];
            var lastDateTimeIn = self.parseWcfJsonDate(vehicle.LastDateTimeIn);
            var timeIn = (Date.now() - lastDateTimeIn.getTime()) / (60 * 1000);

            vehicleViewModel.addVehicle(new Vehicle(vehicle, timeIn));
        }

        vehicleViewModel.lastRefreshDateTime(new Date().toLocaleString());
        self.clearError();
    };

    self.parseWcfJsonDate = function(jsonDateString) {
        var indexOfOpenParen = jsonDateString.indexOf('(');
        var indexOfCloseParen = jsonDateString.indexOf(')');
        var datePortion = jsonDateString.substring(indexOfOpenParen + 1, indexOfCloseParen);

        return new Date(parseInt(datePortion));
    };

    self.getStationList = function() {
        self.makeServiceCall('GetStations', '', self.stationListReturned);
    };

    self.getVehiclesToLoad = function(loadStation) {
        if (loadStation === undefined) {
            loadStation = '';
        }

        var callData = '{ "locationID": "1", "loadStationID": "'+ loadStation + '" }';
        self.makeServiceCall('GetVehiclesToLoad', callData, self.vehiclesReturned)
    };

    self.setVehicleLoaded = function(vehicle, selectedStation) {
        var splitLoad = 'N';

        if (vehicle.isSplitLoad) {
            splitLoad = 'Y';
        }

        var callData = '{ "carrierID": "' + vehicle.carrierId + '", "vehicleID": "' + vehicle.id + '", "locationID": "1", "loadStationID": "' + selectedStation + '", "isSplitLoad": "' + splitLoad + '" }';
        self.makeServiceCall('SetVehicleToLoadStatus', callData);
    };

    self.setVehicleCheckOut = function(vehicle) {
        var callData = '{ "carrierID": "' + vehicle.carrierId + '", "vehicleID": "' + vehicle.id + '" }';
        self.makeServiceCall('SetVehicleToInOutStatus', callData);
    };
}
