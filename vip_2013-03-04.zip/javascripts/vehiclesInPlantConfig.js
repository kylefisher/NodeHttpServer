/**
 * Created with JetBrains WebStorm.
 * User: KFisher
 * Date: 3/4/13
 * Time: 2:39 PM
 * To change this template use File | Settings | File Templates.
 */
var vehiclesInPlantConfig = {
    // url: 'http://ks-kfisher-vm6:8000/Cai/Apex/Services/Ticket/VehiclesInPlant/', // virtual machine host
    serviceAddress: 'http://ks-kfisher-d01:8001/Cai/Apex/Services/Ticket/VehiclesInPlant/',
    refreshInterval: 30000
};