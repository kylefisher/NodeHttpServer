
// Creates the view model.
function VehiclesViewModel(repository) {
    var self = this;
    self.repository = repository;

    self.lastRefreshDateTime = ko.observable();

    self.errorMessage = ko.observable();

    self.showError = function(error) {
        self.errorMessage(error);
        $('#error').css('display', 'block')
    }

    self.hideError = function() {
        //self.errorMessage(undefined);
        $('#error').css('display', 'none');

        if (self.errorMessage() !== undefined)
        {
            location.reload(true);
        }
    }

    //
    // Station View Model
    //
    self.selectedStation = ko.observable('');

    self.selectedStationData = ko.observable();
    self.stations = ko.observableArray([]);

    self.addStation = function(station) {
        self.stations.push(station);
    }

//    self.selectStation = function(station) {
//        self.selectedStation(station.id);
//        self.selectedStationData(station);
//
//        // filter vehicles based on station
//        self.updateModel();
//
//        return self.selectedStation();
//    }

    //
    // Vehicle View Model
    //

    self.selectedVehicle = ko.observable();
    self.selectedVehicleData = ko.observable();
    self.vehicles = ko.observableArray([]);

    self.selectVehicle = function(vehicle) {
        self.selectedVehicle(vehicle);
        self.selectedVehicleData(vehicle)
        $('#gridView').hide();
    }

    self.setLoaded = function(vehicle) {
        self.repository.setVehicleLoaded(vehicle, self.selectedStation());
        self.vehicles.remove(vehicle);
        self.selectedVehicle(null);
        self.selectedVehicleData(null);
        $('#gridView').show();
    }

    self.setCheckOut = function(vehicle) {
        self.repository.setVehicleCheckOut(vehicle);
        self.vehicles.remove(vehicle);
        self.selectedVehicle(null);
        self.selectedVehicleData(null);
        $('#gridView').show();
    }

    self.setCancel = function(vehicle) {
        self.selectedVehicle(null);
        self.selectedVehicleData(null);
        $('#gridView').show();
    }

    self.addVehicle = function(vehicle) {
        for (var i = 0; i < self.vehicles().length; i++) {
            var current = self.vehicles()[i];
            if (current.id == vehicle.id && current.carrierId === vehicle.carrierId) {
                self.vehicles.remove(current);
            }
        }

        if (vehicle.time() > 30) {
            vehicle.timeStyle('critical');
        }
        else if (vehicle.time() > 10) {
            vehicle.timeStyle('warning');
        }

        self.vehicles.push(vehicle);

        self.vehicles.sort(function (left, right) {
            return left.time() < right.time() ? 1 : -1;
        });
    }

    self.filteredVehicles = ko.computed(function() {
        return ko.utils.arrayFilter(self.vehicles(), function(vehicle) {
            return (self.selectedStation() === '' ||
                (self.selectedStation() === vehicle.loadStation));
        })
    });

    self.averageTime = ko.computed(function() {
        if (self.filteredVehicles().length == 0)
            return 0;

        var totalTime = 0;
        for (var i=0; i < self.filteredVehicles().length; i++) {
            totalTime += self.filteredVehicles()[i].time();
        }

        return Math.round(totalTime / self.filteredVehicles().length);
    });

//            self.updateVehicleTimes = function() {
//                for (var i = 0; i < self.vehicles().length; i++) {
//                    //self.vehicles()[i].time++;
//                    self.vehicles()[i].time(self.vehicles()[i].time() + 1);
//                }
//            }

    //
    // Common
    //
    self.updateModel = function() {
        self.repository.getVehiclesToLoad(self.selectedStation());
    }

}