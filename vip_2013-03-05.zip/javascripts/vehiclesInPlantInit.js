/*
Sample using jQuery's getScript to load javascript instead of using html
Cannot debug through browser when loading this way.
$.ajaxSetup({ async: false});
$.getScript('vehiclesInPlantConfig.js');
$.getScript('/models/Station.js');
$.getScript('/models/Vehicle.js');
$.getScript('/viewmodels/vehiclesInPlantViewModel.js');
$.getScript('AjaxRepository.js');
$.ajaxSetup({ async: true});
*/

$(document).ready(function() {
    ko.applyBindings(
        new VehiclesViewModel(
            new AjaxRepository(vehiclesInPlantConfig),
            vehiclesInPlantConfig));
});