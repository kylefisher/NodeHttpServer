function VehiclesViewModel(repository, configuration) {
    var self = this;
    self.repository = repository;

    self.warningMinutes = configuration.warningMinutes;
    self.criticalMinutes = configuration.criticalMinutes;
    self.refreshInterval = configuration.refreshInterval;

    self.lastRefreshDateTime = ko.observable();

    self.errorMessage = ko.observable();

    self.showError = function(error) {
        self.errorMessage(error);
        $('#error').css('display', 'block')
    }

    self.hideError = function() {
        $('#error').css('display', 'none');

        if (self.errorMessage() !== undefined)
        {
            location.reload(true);
        }
    }

    //
    // Station View Model
    //
    self.selectedStation = ko.observable('');

    self.selectedStationData = ko.observable();
    self.stations = ko.observableArray([]);

    self.addStation = function(station) {
        self.stations.push(station);
    }

    self.updateStations = function(stations) {
        self.stations.removeAll();

        for (var i = 0; i < stations.length; i++) {
            self.stations.push(stations[i]);
        }
    };

    //
    // Vehicle View Model
    //

    self.selectedVehicle = ko.observable();
    self.selectedVehicleData = ko.observable();
    self.vehicles = ko.observableArray([]);

    self.selectVehicle = function(vehicle) {
        self.selectedVehicle(vehicle);
        self.selectedVehicleData(vehicle)
        $('#gridView').hide();
    }

    self.setLoaded = function(vehicle) {
        self.repository.setVehicleLoaded(vehicle, self.selectedStation());
        self.vehicles.remove(vehicle);
        self.selectedVehicle(null);
        self.selectedVehicleData(null);
        $('#gridView').show();
    }

    self.setCheckOut = function(vehicle) {
        self.repository.setVehicleCheckOut(vehicle);
        self.vehicles.remove(vehicle);
        self.selectedVehicle(null);
        self.selectedVehicleData(null);
        $('#gridView').show();
    }

    self.setCancel = function(vehicle) {
        self.selectedVehicle(null);
        self.selectedVehicleData(null);
        $('#gridView').show();
    }

    self.addVehicle = function(vehicle) {
        self.removeVehicle(vehicle);

        if (vehicle.time() > self.criticalMinutes) {
            vehicle.timeStyle('critical');
        }
        else if (vehicle.time() > self.warningMinutes) {
            vehicle.timeStyle('warning');
        }

        self.vehicles.push(vehicle);
    }

    self.removeVehicle = function(vehicle) {
        self.vehicles.remove(function(item) {
            return item.id === vehicle.id && item.carrierId === vehicle.carrierId;
        });
    }

    self.updateVehicles = function(vehicles) {
        for (var i = 0; i < vehicles.length; i++) {
            self.addVehicle(vehicles[i]);
        }

        self.vehicles.sort(function (left, right) {
           return left.time() <= right.time() ? 1 : -1;
        });

        self.lastRefreshDateTime(new Date().toLocaleString());
    }

    self.filteredVehicles = ko.computed(function() {
        return ko.utils.arrayFilter(self.vehicles(), function(vehicle) {
            return (self.selectedStation() === '' ||
                (self.selectedStation() === vehicle.loadStation));
        })
    });

    self.averageTime = ko.computed(function() {
        if (self.filteredVehicles().length == 0)
            return 0;

        var totalTime = 0;
        for (var i=0; i < self.filteredVehicles().length; i++) {
            totalTime += self.filteredVehicles()[i].time();
        }

        return Math.round(totalTime / self.filteredVehicles().length);
    });

    //
    // Common
    //
    self.updateModel = function() {
        self.repository.getVehiclesToLoad(self.selectedStation(), self.updateVehicles);
    }

    //
    // Initialization
    //
    self.repository.setOnError(self.showError);
    self.repository.setOnSuccess(self.hideError);

    self.repository.getStationList(self.updateStations);
    self.repository.getVehiclesToLoad('', self.updateVehicles);
    setInterval(self.updateModel, self.refreshInterval);
}