function Location(id, description) {
    var self = this;
    self.id = id;
    self.description = description;
}